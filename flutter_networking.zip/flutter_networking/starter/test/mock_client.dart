import 'package:mockito/mockito.dart';
import 'package:http/http.dart' as http ;

class MockedClient extends Mock implements http.Client {}