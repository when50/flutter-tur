
import 'package:flutter_test/flutter_test.dart';

void main() {
  group("BookRepository", (){
    test("Testing successful GET request", () {
      //TODO: add test case to check if the GET request is successful
    });

    test("Testing successful DELETE request", () {
      //TODO: add test case to check if the DELETE request is successful
    });

    test("Testing failed delete request", () {
      //TODO: add test case to check the response during failed DELETE request
    });
  });
}
