# book_app

A Flutter application showing the working of GET, POST and DELETE request. 

## Getting Started

To run this app make sure you deploy the companion book_api_app locally.

1) If you have Flutter setup on your machine then type this command in your terminal `pub global activate aqueduct`
2) Copy book_api_app to a particular folder e.g Documents or Downloads.
3) Open terminal and run `cd Download` and `cd book_api_app`
4) Now execute the command `aqueduct serve`
5) Your have successfully deployed the HTTP server.
6) Finally! In order to run the Flutter app make sure your testing device and laptop are connected to the same network.

